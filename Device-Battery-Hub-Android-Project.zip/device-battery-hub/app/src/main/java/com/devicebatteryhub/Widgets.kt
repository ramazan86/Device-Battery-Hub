package com.devicebatteryhub

import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.widget.RemoteViews
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private fun shown(value: Int?): String = value?.let { "$it%" } ?: "--%"

object WidgetUpdater {
    fun updateAll(context: Context) {
        BatteryData.refreshPhone(context)
        val manager = AppWidgetManager.getInstance(context)
        listOf(CombinedWidget::class.java, PhoneWidget::class.java, WatchWidget::class.java, EarbudsWidget::class.java)
            .forEach { cls ->
                val ids = manager.getAppWidgetIds(ComponentName(context, cls))
                if (ids.isNotEmpty()) when (cls) {
                    CombinedWidget::class.java -> CombinedWidget().onUpdate(context, manager, ids)
                    PhoneWidget::class.java -> PhoneWidget().onUpdate(context, manager, ids)
                    WatchWidget::class.java -> WatchWidget().onUpdate(context, manager, ids)
                    EarbudsWidget::class.java -> EarbudsWidget().onUpdate(context, manager, ids)
                }
            }
    }
}

class CombinedWidget : AppWidgetProvider() {
    override fun onUpdate(context: Context, manager: AppWidgetManager, ids: IntArray) {
        BatteryData.refreshPhone(context)
        ids.forEach { id ->
            val views = RemoteViews(context.packageName, R.layout.widget_combined)
            views.setTextViewText(R.id.phone_value, shown(BatteryData.phone(context)))
            views.setTextViewText(R.id.watch_value, shown(BatteryData.watch(context)))
            views.setTextViewText(R.id.earbuds_value, shown(BatteryData.earbuds(context)))
            views.setTextViewText(R.id.earbuds_left_value, shown(BatteryData.earbudsLeft(context)))
            views.setTextViewText(R.id.earbuds_right_value, shown(BatteryData.earbudsRight(context)))
            views.setTextViewText(R.id.earbuds_case_value, shown(BatteryData.earbudsCase(context)))
            val updated = BatteryData.lastUpdated(context)?.let {
                "Данные Bluetooth: ${SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date(it))}"
            } ?: "Bluetooth: ожидаем данные от устройств"
            views.setTextViewText(R.id.updated, updated)
            manager.updateAppWidget(id, views)
        }
    }
}

abstract class SingleWidget : AppWidgetProvider() {
    abstract val title: String
    abstract val subtitle: String
    abstract fun level(context: Context): Int?
    override fun onUpdate(context: Context, manager: AppWidgetManager, ids: IntArray) {
        BatteryData.refreshPhone(context)
        ids.forEach { id ->
            val views = RemoteViews(context.packageName, R.layout.widget_small)
            views.setTextViewText(R.id.small_title, title)
            views.setTextViewText(R.id.small_value, shown(level(context)))
            views.setTextViewText(R.id.small_subtitle, subtitle)
            manager.updateAppWidget(id, views)
        }
    }
}
class PhoneWidget : SingleWidget() {
    override val title = "ТЕЛЕФОН"
    override val subtitle = "vivo X300 FE"
    override fun level(context: Context) = BatteryData.phone(context)
}
class WatchWidget : SingleWidget() {
    override val title = "ЧАСЫ"
    override val subtitle = "Huawei GT 5 Pro"
    override fun level(context: Context) = BatteryData.watch(context)
}
class EarbudsWidget : SingleWidget() {
    override val title = "НАУШНИКИ"
    override val subtitle = "Soundcore Liberty 5 Pro"
    override fun level(context: Context) = BatteryData.earbuds(context)
}
