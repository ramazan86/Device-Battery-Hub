package com.devicebatteryhub

import android.Manifest
import android.app.Activity
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothManager
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

class MainActivity : Activity() {
    private val green = 0xFF65E6A6.toInt()
    private val muted = 0xFF9BAAB8.toInt()
    private val panel = 0xFF101720.toInt()
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        BatteryData.refreshPhone(this)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(24, 34, 24, 24); setBackgroundColor(0xFF090D12.toInt())
        }
        root.addView(TextView(this).apply { text = "DEVICE BATTERY HUB"; textSize = 21f; setTextColor(green); letterSpacing = .08f })
        root.addView(TextView(this).apply {
            text = "Три устройства. Один экран.\nНеизвестный заряд отмечается как «Нет данных»."; textSize = 14f; setTextColor(muted); setPadding(0, 8, 0, 24)
        })
        addDevice(root, "📱  vivo X300 FE", BatteryData.phone(this))
        addDevice(root, "⌚  Huawei Watch GT 5 Pro", BatteryData.watch(this))
        addDevice(root, "🎧  Soundcore Liberty 5 Pro — общий", BatteryData.earbuds(this))
        addDevice(root, "Левый наушник", BatteryData.earbudsLeft(this))
        addDevice(root, "Правый наушник", BatteryData.earbudsRight(this))
        addDevice(root, "Зарядный кейс", BatteryData.earbudsCase(this))
        root.addView(TextView(this).apply {
            text = "Добавьте виджеты на главный экран: удерживайте пустое место на рабочем столе → Виджеты → Device Battery Hub. Доступны общий виджет и три отдельных.";
            textSize = 13f; setTextColor(muted); setPadding(0, 20, 0, 20)
        })
        root.addView(Button(this).apply {
            text = "Разрешить доступ к Bluetooth"; setOnClickListener { requestBluetoothPermission() }
        })
        root.addView(Button(this).apply {
            text = "Обновить данные"; setOnClickListener { WidgetUpdater.updateAll(this@MainActivity); recreate() }
        })
        root.addView(TextView(this).apply {
            text = "Важно: часы, отдельные наушники и кейс появятся здесь только если Android передаст их уровень заряда через стандартный Bluetooth-интерфейс. Фирменные приложения не гарантируют доступ сторонним приложениям.";
            textSize = 12f; setTextColor(muted); setPadding(0, 18, 0, 0)
        })
        setContentView(root)
    }
    private fun addDevice(root: LinearLayout, name: String, value: Int?) {
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(18, 14, 18, 14); setBackgroundColor(panel)
        }
        card.addView(TextView(this).apply { text = name; textSize = 14f; setTextColor(muted) })
        card.addView(TextView(this).apply { text = value?.let { "$it%" } ?: "Нет данных"; textSize = 27f; setTextColor(green) })
        val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        lp.bottomMargin = 10; root.addView(card, lp)
    }
    private fun requestBluetoothPermission() {
        if (Build.VERSION.SDK_INT >= 31 && checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED)
            requestPermissions(arrayOf(Manifest.permission.BLUETOOTH_CONNECT), 41)
        else showPairedDevices()
    }
    private fun showPairedDevices() {
        val names = try {
            val manager = getSystemService(Context.BLUETOOTH_SERVICE) as BluetoothManager
            val adapter: BluetoothAdapter? = manager.adapter
            adapter?.bondedDevices?.mapNotNull { it.name } ?: emptyList()
        } catch (_: SecurityException) { emptyList() }
        android.widget.Toast.makeText(this, if (names.isEmpty()) "Нет доступных сопряжённых устройств" else "Сопряжённые устройства: ${names.joinToString()}", android.widget.Toast.LENGTH_LONG).show()
    }
    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 41 && grantResults.firstOrNull() == PackageManager.PERMISSION_GRANTED) showPairedDevices()
    }
}
