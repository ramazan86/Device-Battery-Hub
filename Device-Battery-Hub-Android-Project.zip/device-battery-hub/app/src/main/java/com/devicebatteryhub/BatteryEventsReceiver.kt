package com.devicebatteryhub

import android.bluetooth.BluetoothDevice
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build

class BatteryEventsReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        when (intent.action) {
            BluetoothDevice.ACTION_BATTERY_LEVEL_CHANGED -> {
                val device = if (Build.VERSION.SDK_INT >= 33)
                    intent.getParcelableExtra(BluetoothDevice.EXTRA_DEVICE, BluetoothDevice::class.java)
                else @Suppress("DEPRECATION") intent.getParcelableExtra(BluetoothDevice.EXTRA_DEVICE)
                val level = intent.getIntExtra(BluetoothDevice.EXTRA_BATTERY_LEVEL, -1)
                val name = try { device?.name.orEmpty() } catch (_: SecurityException) { "" }
                val key = BatteryData.keyForDevice(name)
                if (key != null && level in 0..100) BatteryData.save(context, key, level)
                WidgetUpdater.updateAll(context)
            }
            Intent.ACTION_BOOT_COMPLETED -> WidgetUpdater.updateAll(context)
        }
    }
}
