package com.devicebatteryhub

import android.content.Context
import android.content.Intent
import android.os.BatteryManager

object BatteryData {
    private const val PREFS = "battery_data"
    const val PHONE = "phone"
    const val WATCH = "watch"
    const val EARBUDS = "earbuds"
    const val EARBUDS_LEFT = "earbuds_left"
    const val EARBUDS_RIGHT = "earbuds_right"
    const val EARBUDS_CASE = "earbuds_case"
    private const val LAST_UPDATE = "last_update"

    fun save(context: Context, key: String, level: Int) {
        if (level in 0..100) context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .edit().putInt(key, level).putLong(LAST_UPDATE, System.currentTimeMillis()).apply()
    }

    fun get(context: Context, key: String): Int? {
        val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        return if (prefs.contains(key)) prefs.getInt(key, -1).takeIf { it in 0..100 } else null
    }

    fun lastUpdated(context: Context): Long? = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        .getLong(LAST_UPDATE, 0L).takeIf { it > 0L }

    fun refreshPhone(context: Context) {
        val intent = context.registerReceiver(null, android.content.IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        val level = intent?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1
        val scale = intent?.getIntExtra(BatteryManager.EXTRA_SCALE, -1) ?: -1
        if (level >= 0 && scale > 0) save(context, PHONE, (level * 100) / scale)
    }

    fun phone(context: Context) = get(context, PHONE)
    fun watch(context: Context) = get(context, WATCH)
    fun earbuds(context: Context) = get(context, EARBUDS)
    fun earbudsLeft(context: Context) = get(context, EARBUDS_LEFT)
    fun earbudsRight(context: Context) = get(context, EARBUDS_RIGHT)
    fun earbudsCase(context: Context) = get(context, EARBUDS_CASE)

    /** Standard Android Bluetooth battery events only. Vendor-specific values may not be exposed. */
    fun keyForDevice(name: String): String? {
        val n = name.lowercase()
        return when {
            "huawei" in n || "watch gt" in n || "gt 5" in n -> WATCH
            "soundcore" in n || "liberty" in n || "anker" in n -> when {
                "case" in n || "charging" in n || "кейс" in n -> EARBUDS_CASE
                "left" in n || "лев" in n -> EARBUDS_LEFT
                "right" in n || "прав" in n -> EARBUDS_RIGHT
                else -> EARBUDS
            }
            else -> null
        }
    }
}
